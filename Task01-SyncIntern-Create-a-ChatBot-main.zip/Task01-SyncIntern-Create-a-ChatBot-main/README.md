# Task01-SyncIntern-Create-a-ChatBot

Chatbots are nothing but applications that are used by businesses or other entities to conduct an automatic conversation between a human 
and an AI. These conversations may be via text or speech. Chatbots are required to understand and mimic human conversation while interacting
with humans from all over the world. From the first chatbot to be created ELIZA to Amazon’s ALEXA today, chatbots have come a long way. 
In this project, i have create a basic chatbot that can understand human interaction and also respond accordingly using NLP.
