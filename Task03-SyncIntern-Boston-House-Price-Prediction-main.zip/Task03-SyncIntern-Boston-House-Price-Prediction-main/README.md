# Task03-SyncIntern-Boston-House-Price-Prediction
Overview

Housing prices are an important reflection of the economy, and housing price ranges are of great interest for both buyers and sellers. In this project, house prices will be predicted given explanatory variables that cover many aspects of residential houses.
In the Boston House Price Prediction Project, we are building a predictive model to evaluate the price of a house with provided parameters. The parameters into consideration are - Per Capita Crime Rate by Town, Nitric Oxide Concentration, Average number of Rooms, Tax etc.
Moreover, this project can be developed for real-time applications in any city, helping developers, realtors, and buyers predict property value also very valuable for a real state agent who could make use of the information provided in a daily basis.
In this project, we will develop and evaluate the performance and the predictive power of a model trained and tested on data collected from houses in Boston’s suburbs. Once we get a good fit, we will use this model to predict the monetary value of a house located at the Boston’s area. We will use - Linear Regression, Decision Tree, Random Forest & XG Boost algorithm and compare the model accuracy.

Problem Statement

Here, the goal is to build a model that can predict the price of a property based on parameters like crime rate, age of the property, air quality, Average number of Rooms, Tax etc.

About dataset

The Boston Housing Data has 506 rows and 14 columns, business meaning of each column in the data is as below:

CRIM - per capita crime rate by town

ZN - proportion of residential land zoned for lots over 25,000 sq.ft.

INDUS - proportion of non-retail business acres per town.

CHAS - Charles River dummy variable (1 if tract bounds river; 0 otherwise)

NOX - nitric oxides concentration (parts per 10 million)

RM - average number of rooms per dwelling

AGE - Proportion of owner-occupied units built before 1940

DIS - weighted distances to five Boston employment centres

RAD - index of accessibility to radial highways

TAX - property tax rate per $10,000

PTRATIO - pupil/teacher ratio by town

B - Proportion of people of African American descent (1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town)

LSTAT - % of Lower Status of the Population

MEDV - Median value of owner-occupied homes in $1000, i.e., Price of the property
